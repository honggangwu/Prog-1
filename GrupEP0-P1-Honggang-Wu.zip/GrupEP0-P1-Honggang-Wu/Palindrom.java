/*
 * Autor:Honggang wu
 * Data:   dd/mm/aa
 * Versió: 1.0
 */

/*
 * P1 - Prog 25-26
 * Exercici 26.	Feu un programa que indiqui si una paraula entrada per teclat és palíndrom.
 * No es pot suposar que totes les lletres de la paraula s’escriuen en minúscula.
 * Recorda que hi ha un mètode toLowerCase() de la classe String.
 * Per exemple: la paraula “Refer” ha de sortir com palíndrom, i “ahir”
 * ha de sortir com no palíndrom (Palindrom.java)
 */

/* Taula de tests
  Entrada            | Sortida esperada
  -------------------------------------
         Refer       | es palindrom
         ahir        | no es palindrom
                     |
  		             |
*/
import java.util.Scanner;

public class Palindrom {
    public static void main(String[] args){
	String paraula,paraulamin;
        Scanner teclat=  new Scanner(System.in);
	System.out.println("Entra una paraula");
	paraula=teclat.nextLine();
	paraulamin=paraula.toLowerCase();
	boolean esPalindrom=palindrom(paraulamin);
	if (esPalindrom){
		System.out.println("Es palindrom");
	}else{
		System.out.println("No es palindrom");
	}
    }
    public static boolean palindrom(String cadena){
        int n= cadena.length();
	for(int i=0;i<(n/2);i++){
	if(cadena.charAt(i)==cadena.charAt(n-1-i)){
		return true;
		}
   	}
	return false;
    }
}
