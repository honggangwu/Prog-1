/*
 * Autor:  Honggang Wu
 * Data:   dd/mm/aa
 * Versió: 1.0
 */

/*
 * P1 - Prog 25-26
 * Exercici 32.	Feu un programa que demani un enter n, seguidament llegeixi n enters
 * i finalment retorni la mitjana dels nombres parells. (MitjanaParells.java)
 */


import java.util.Scanner;

/* Taula de tests
  Entrada            | Sortida esperada
  -------------------------------------
      4 1,2,3,4      |  3.0
                     |
                     |
  		     |
*/
public class MitjanaParells {
    public static void main(String[] args){
        Scanner teclat= new Scanner(System.in);
	System.out.println("entra un numero enter");
	int n;
	float mitjana;
	n=teclat.nextInt();
	mitjana=mitjanaParells(teclat,n);
	System.out.println("La mitjana dels parells es " + mitjana);

    }
    public static float mitjanaParells(Scanner teclado, int n) {
	int sumaParells=0;
	int contador=0;
        for(int i=0;i<n;i++){
		System.out.println("Entra un numero enter");
		int num=teclado.nextInt();
		if(num%2==0){
		sumaParells+=num;
		contador++;
		}	
	}
	float mitjana=(float) sumaParells/contador;
	return mitjana;
    }
}
