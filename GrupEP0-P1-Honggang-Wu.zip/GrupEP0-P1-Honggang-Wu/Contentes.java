/*
 * Autor:  Honggang Wu
 * Data:   dd/mm/aa
 * Versió: 1.0
 */

/*
 * P1 - Prog 25-26
 * Exercici 28.	Feu un programa per a veure si cada caràcter ‘a’ d’una paraula llegida
 * per teclat està contenta. Una ‘a’ està contenta si té a la seva esquerra o a la seva dreta
 * una altre ‘a’. El programa ens diu si totes les ‘a’ estan contentes.
 * Per exemple: si introduïm “zdaaaoa” el programa mostra el missatge
 * “No totes les a estan contentes”,
 * amb la cadena “zdaa” el programa mostra “Totes les a estan contentes (Contentes.java)
 */


/* Taula de tests
  Entrada            | Sortida esperada
  -------------------------------------
           zdaa      | Totes les a estan contentes
         zzdaaaoa    | No totes les a estan contentes
                     |
  		     |
*/
import java.util.Scanner;

public class Contentes {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        System.out.println("Entra una cadena");
	String cadena;
 	cadena=sc.nextLine();
	boolean estanContentes=contentes(cadena);
	if(estanContentes){
		System.out.println("Totes les a estan contentes");
	}else{
		System.out.println("No totes les a estan contentes");
	}
    }
    public static boolean contentes(String cadena){
       int n=cadena.length();
      for(int i =0; i< n; i++){
      	if (cadena.charAt(i)=='a'){
		boolean esquerra=(i>0 && cadena.charAt(i-1)=='a');
		boolean dreta=(i<n-1 && cadena.charAt(i+1)=='a');
		
		if(!dreta && !esquerra){
			return false;
		}
	}
      } 
        return true;
    }
}
