/*
 * Autor:  Honggang Wu
 * Data:   dd/mm/aa
 * Versió: 1.0
 */

/*
 * P1 - Prog 25-26
 * Exercici 24.	Feu un programa que llegeix un String i compta el nombre de vocals
 * que hi ha en total. Per exemple, “Avui fa molta calor.” dona el missatge
 * “La frase té 8 vocals”. Utilitza el mètode CharAt() de la classe String per a resoldre’l.
 * (CompteVocals.java)
 */


/* Taula de tests
  Entrada            | Sortida esperada
  -------------------------------------
  Avui fa molta calor| La frase te 8 vocalss
                     |
                     |
  		             |
*/
import java.util.Scanner;

public class CompteVocals {
    public static void main(String[] args){
    	String cadena;
	int recompteVocals;
	Scanner teclat=  new Scanner(System.in);
    	System.out.println("Entra una cadena");
	cadena=teclat.nextLine();
	recompteVocals=compteVocals(cadena);
	System.out.println("La frase té "+ recompteVocals+ " vocals");	
    }
    public static int compteVocals(String cadena){
        int cont=0;
	String vocals="aeiouAEIOU";
	int n=cadena.length();
	for(int i=0;i<n;i++){
		char c=cadena.charAt(i);
		if (vocals.indexOf(c)!=-1){
			cont++;
		}
	}

        return cont;
    }
}
